# from flask import Blueprint, render_template, jsonify, request, flash, send_from_directory, flash, redirect, url_for
# from flask_jwt_extended import jwt_required, current_user, unset_jwt_cookies, set_access_cookies, decode_token, get_jwt_identity, jwt_authenticate


# from.index import index_views

# from App.controllers import *

# auth_views = Blueprint('auth_views', __name__, template_folder='../templates')


# '''
# Page/Action Routes
# '''    

# @auth_views.route('/api/identify', methods=['GET'])
# @jwt_required()
# def identify_user():
#     try:
#         current_identity = get_user(get_jwt_identity())
#     except Exception as e:
#         return jsonify({"error": str(e)}), 500
#     return jsonify({'message': f"username: {current_identity.username}, id : {get_jwt_identity()}, type: {current_identity.user_type}"})
    

# @auth_views.route('/api/login', methods=['POST'])
# def login_action():
#     data = request.json

#     if not data or not data.get('username') or not data.get('password'):
#         return jsonify({"error": "Username and password are required"}), 400

#     token = jwt_authenticate(data['username'], data['password'])

#     if not token:
#         return jsonify({"error": "Bad username or password given"}), 401

#     decoded_token = decode_token(token)
#     user_identity = decoded_token['sub']   
#     user_type = decoded_token.get('user_type')
#     username = decoded_token.get('username')

#     return jsonify({
#         "access_token": token,
#         "user_id": user_identity,
#         "username": username,
#         "user_type": user_type
#     }), 200
    
# @auth_views.route('/api/logout', methods=['GET'])
# def logout_action():
#     response = jsonify(message="Logged Out!")
#     unset_jwt_cookies(response)
#     return response
