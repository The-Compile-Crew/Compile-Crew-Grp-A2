from App.models import Request, Driver
from App.database import db

def create_request(resident_id, driverId, description=None):
    request = Request(residentId=resident_id, driveId=driverId, description=description)
    db.session.add(request)
    db.session.commit()
    return request

def get_all_requests():
    requests= Request.query.all()
    return requests

def get_requests_by_drive(drive_id):
    requests_by_drive = Request.query.filter_by(driveId=drive_id).all()
    return [r.toJSON() for r in requests_by_drive]

#accept or reject request
def update_request_status(driverId, request_id, status):
    driver = Driver.query.get(driverId)
    if driver is None:
        return None
    else:
        request = Request.query.get(request_id)
        if request:
            request.status = status
            db.session.commit()
        return request